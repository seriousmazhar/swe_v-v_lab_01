package OnlineShop;

public class Payment {
    public int TotalPrice;

    public int MakePayment(int totalPrice){
        System.out.println("Total price: " + totalPrice);

        return totalPrice;
    }
}
